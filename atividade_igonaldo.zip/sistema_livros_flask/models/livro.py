import sqlite3
from models.database import CAMINHO_BANCO


class Livro:
    """Modelo Livro: mantém todos os comandos SQL do cadastro nesta classe."""

    def __init__(self, titulo, autor, ano):
        self.titulo = titulo.strip()
        self.autor = autor.strip()
        self.ano = int(ano)

    @staticmethod
    def conectar():
        """Abre a conexão com o banco SQLite."""
        conexao = sqlite3.connect(CAMINHO_BANCO)
        conexao.row_factory = sqlite3.Row
        return conexao

    @classmethod
    def criar_tabela(cls):
        """Cria a tabela de livros caso ainda não exista."""
        conexao = cls.conectar()
        try:
            conexao.execute("""
                CREATE TABLE IF NOT EXISTS livros (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    titulo TEXT NOT NULL,
                    autor TEXT NOT NULL,
                    ano INTEGER NOT NULL
                )
            """)
            conexao.commit()
        finally:
            conexao.close()

    def salvar(self):
        """Insere este objeto Livro no banco e confirma a gravação."""
        conexao = self.conectar()
        try:
            conexao.execute(
                "INSERT INTO livros (titulo, autor, ano) VALUES (?, ?, ?)",
                (self.titulo, self.autor, self.ano)
            )
            conexao.commit()
        finally:
            conexao.close()

    @classmethod
    def listar_todos(cls):
        """Retorna os livros salvos no banco, do mais novo para o mais antigo."""
        conexao = cls.conectar()
        try:
            cursor = conexao.execute(
                "SELECT id, titulo, autor, ano FROM livros ORDER BY id DESC"
            )
            return cursor.fetchall()
        finally:
            conexao.close()
