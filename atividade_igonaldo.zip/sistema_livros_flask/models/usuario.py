import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from models.database import CAMINHO_BANCO


class Usuario:
    """Modelo de usuário: concentra as operações SQL da tabela usuarios."""

    def __init__(self, nome, senha):
        self.nome = nome.strip()
        self.senha = senha

    @staticmethod
    def conectar():
        conexao = sqlite3.connect(CAMINHO_BANCO)
        conexao.row_factory = sqlite3.Row
        return conexao

    @classmethod
    def criar_tabela(cls):
        conexao = cls.conectar()
        try:
            conexao.execute("""
                CREATE TABLE IF NOT EXISTS usuarios (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL UNIQUE,
                    senha TEXT NOT NULL
                )
            """)
            conexao.commit()
        finally:
            conexao.close()

    def cadastrar(self):
        """Salva o usuário com a senha protegida por hash."""
        conexao = self.conectar()
        try:
            senha_hash = generate_password_hash(self.senha)
            conexao.execute(
                "INSERT INTO usuarios (nome, senha) VALUES (?, ?)",
                (self.nome, senha_hash)
            )
            conexao.commit()
        finally:
            conexao.close()

    @classmethod
    def buscar_por_nome(cls, nome):
        conexao = cls.conectar()
        try:
            cursor = conexao.execute(
                "SELECT id, nome, senha FROM usuarios WHERE nome = ?",
                (nome,)
            )
            return cursor.fetchone()
        finally:
            conexao.close()

    @staticmethod
    def senha_correta(senha_digitada, senha_hash):
        return check_password_hash(senha_hash, senha_digitada)
