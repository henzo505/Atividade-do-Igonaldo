from pathlib import Path
import sqlite3

CAMINHO_BANCO = Path(__file__).resolve().parent.parent / "livros.db"


def conectar():
    """Abre uma conexão com o banco SQLite."""
    conexao = sqlite3.connect(CAMINHO_BANCO)
    conexao.row_factory = sqlite3.Row
    return conexao


def init_db():
    """Mantido para compatibilidade; as tabelas são criadas pelos modelos."""
    from models.usuario import Usuario
    Usuario.criar_tabela()
