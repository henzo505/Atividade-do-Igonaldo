from flask import Flask, redirect, url_for, session, request, render_template
from controllers.auth_controller import auth_bp
from controllers.livro_controller import livro_bp
from models.database import init_db
from models.livro import Livro
from models.usuario import Usuario

app = Flask(__name__, template_folder="views")
app.config["SECRET_KEY"] = "troque-esta-chave-em-um-projeto-real"

app.register_blueprint(auth_bp)
app.register_blueprint(livro_bp)


@app.before_request
def verificar_login():
    """Protege páginas internas; login, cadastro e arquivos estáticos são públicos."""
    rotas_publicas = ["auth.login", "auth.cadastrar_usuario", "static"]
    if request.endpoint is None or request.endpoint in rotas_publicas:
        return None
    if "usuario" not in session:
        return redirect(url_for("auth.login"))
    return None


@app.route("/")
def inicio():
    return redirect(url_for("home"))


@app.route("/home")
def home():
    return render_template("home.html", usuario=session["usuario"])


if __name__ == "__main__":
    init_db()
    Usuario.criar_tabela()
    Livro.criar_tabela()
    app.run(debug=True)
