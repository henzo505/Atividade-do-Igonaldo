from flask import Blueprint, render_template, request, redirect, url_for, flash
from models.livro import Livro

livro_bp = Blueprint("livros", __name__)


@livro_bp.route("/livros")
def listar_livros():
    # A rota pede à classe os dados reais do SQLite; não há SQL aqui.
    livros = Livro.listar_todos()
    return render_template("listar_livros.html", livros=livros)


@livro_bp.route("/livros/novo", methods=["GET", "POST"])
def cadastrar_livro():
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        autor = request.form.get("autor", "").strip()
        ano_texto = request.form.get("ano", "").strip()

        # Validação dos dados recebidos do formulário.
        if not titulo or not autor or not ano_texto:
            flash("Preencha todos os campos.")
            return render_template("cadastro_livro.html")

        try:
            ano = int(ano_texto)
            if ano < 0 or ano > 2100:
                raise ValueError
        except ValueError:
            flash("Informe um ano válido.")
            return render_template("cadastro_livro.html")

        livro = Livro(titulo, autor, ano)
        livro.salvar()
        flash("Livro cadastrado com sucesso!")
        return redirect(url_for("livros.listar_livros"))

    return render_template("cadastro_livro.html")
