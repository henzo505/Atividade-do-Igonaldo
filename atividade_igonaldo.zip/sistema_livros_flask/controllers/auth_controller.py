import sqlite3
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from models.usuario import Usuario

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        senha = request.form.get("senha", "")
        usuario = Usuario.buscar_por_nome(nome)

        if usuario and Usuario.senha_correta(senha, usuario["senha"]):
            session.clear()
            session["usuario"] = usuario["nome"]
            session["usuario_id"] = usuario["id"]
            return redirect(url_for("home"))

        flash("Usuário ou senha incorretos.")

    return render_template("login.html")


@auth_bp.route("/cadastro", methods=["GET", "POST"])
def cadastrar_usuario():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        senha = request.form.get("senha", "")
        confirmar = request.form.get("confirmar_senha", "")

        if len(nome) < 3:
            flash("O usuário precisa ter pelo menos 3 caracteres.")
            return render_template("cadastro_usuario.html")
        if len(senha) < 4:
            flash("A senha precisa ter pelo menos 4 caracteres.")
            return render_template("cadastro_usuario.html")
        if senha != confirmar:
            flash("As senhas não coincidem.")
            return render_template("cadastro_usuario.html")

        try:
            Usuario(nome, senha).cadastrar()
        except sqlite3.IntegrityError:
            flash("Esse nome de usuário já está cadastrado. Escolha outro.")
            return render_template("cadastro_usuario.html")

        flash("Usuário cadastrado! Agora você pode entrar.")
        return redirect(url_for("auth.login"))

    return render_template("cadastro_usuario.html")


@auth_bp.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("auth.login"))
